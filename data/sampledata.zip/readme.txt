Due to the big data size , we only provide sample data of our experiments.
sampleweibo.txt  is the sample data of  weibo we obtained.
sampletweets.txt is the sample data of twitter we obtained.
samplecityblocks.txt  is the city block data.
samplesocialview.txt is the  social view data.
samplephysicalview.txt is the physical view data.
sampletrain.txt is the sample train data. 
samplemiddledata.txt  is the sample data after FDA2 and before autoencoding. 
For source data of experiments https://github.com/zxlzr/UrbanWaterloggingInference.